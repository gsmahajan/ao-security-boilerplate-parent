#! /bin/bash

#	
#	 ______                  _____                __              __     
#	/\  _  \                /\  __`\             /\ \      __    /\ \    
#	\ \ \L\ \  _____   _____\ \ \/\ \  _ __   ___\ \ \___ /\_\   \_\ \   
#	 \ \  __ \/\ '__`\/\ '__`\ \ \ \ \/\`'__\/'___\ \  _ `\/\ \  /'_` \  
#	  \ \ \/\ \ \ \L\ \ \ \L\ \ \ \_\ \ \ \//\ \__/\ \ \ \ \ \ \/\ \L\ \ 
#	   \ \_\ \_\ \ ,__/\ \ ,__/\ \_____\ \_\\ \____\\ \_\ \_\ \_\ \___,_\
#	    \/_/\/_/\ \ \/  \ \ \/  \/_____/\/_/ \/____/ \/_/\/_/\/_/\/__,_ /
#	             \ \_\   \ \_\                                           
#	              \/_/    \/_/                                           
#	
#
#
# Credit - girish.mahajan@accionlabs.com
#

function log_warn {
        echo -e `date +%d/%m/%Y-%H:%M:%S ` "\033[33m# WARNING # " $1 "\033[0m" | tee -a $LOGFILE;
}

function log_info {
         echo -e `date +%d/%m/%Y-%H:%M:%S ` "\033[32m# INFO    # " $1 "\033[0m" | tee -a $LOGFILE;
}

function log_debug {
         echo -e `date +%d/%m/%Y-%H:%M:%S ` "\033[32m# INFO    # " $1 "\033[0m" | tee -a $LOGFILE;
}

function log_error {
        echo -e `date +%d/%m/%Y-%H:%M:%S ` "\033[31m# ERROR   # " $1 "\033[0m" | tee -a $LOGFILE;
}


function renewIndexesES {
rm -rf ./esindexes/

log_warn "Removing awsecurity_search_users index"

curl -X DELETE localhost:9200/awsecurity_search_users

log_warn "Removing all ES indexes"

# careful
# curl -X DELETE localhost:9200/_all

log_warn "Renew ES index awsecurity_search_users"

arangoexport --server.password 14edcd1c2b7ff3b42823eac1eeb5d456 --overwrite true --type csv --collection cloudseer_peoples --fields displayName,logon,badgeId,empNum,empId,_key --output-directory esindexes

sed -i "s/empId,_key/empId,dbKey/g" esindexes/cloudseer_peoples.csv

log_debug "exported people csv sample -> for ES index"

head -4 esindexes/cloudseer_peoples.csv


log_info "importing into elastic now"

# no real time
cat esindexes/cloudseer_peoples.csv | /apporchid/solutions/awsecurity/apps/logstash-6.2.2/bin/logstash -e 'input {stdin {}} filter { csv { columns =>[ "displayName", "logon", "badgeId", "empNum", "empId", "dbKey" ] separator => "," }} filter { mutate { convert => { "badgeId" => "integer" } }} output { elasticsearch { index => "awsecurity_search_users" } stdout { codec => rubydebug {} }}'

log_info "ES index back online"

curl -i http://localhost:9200/_cat/indices
log_info "count of index in awsecurity_search_users"
curl -i http://localhost:9200/_cat/count/awsecurity_search_users

}

renewIndexesES

